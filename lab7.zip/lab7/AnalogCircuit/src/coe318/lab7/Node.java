package coe318.Lab7;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Node {
    public int id;
    private static int counter = 0;
    public Node(){
        this.id = counter;
        counter++;
    }
    @Override
    public String toString (){
        return "" + this.id;
    }
     
}
