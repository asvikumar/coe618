package coe318.Lab7;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Resistor {
    int resistorId;
    double Resistance;
    Node node1, node2;
    static int counter = 1;
    public Resistor (double Resistance, Node node1, Node node2){
        if (Resistance > 0) {
        } else {
            throw new IllegalArgumentException("N/A");
        }
        if (node1 == null || node2 == null)
            throw new IllegalArgumentException("N/A");
            
        this.Resistance = Resistance;
        this.node1 = node1;
        this.node2 = node2;
        resistorId = counter;
        counter ++;   
        }
    
    public Node[] getNode(){
        return new Node[]{node1, node2};
        }
    
    @Override
    public String toString(){
        Node[] n = getNode();
         if (n[0].id > n[1].id){
             return ("R" + "" + this.resistorId + " "+ node1+" " + node2 + " " + Resistance);
        }
        else{
          return ("R" + "" + this.resistorId + " "+ node1+" " + node2 + " " + Resistance);
        }
    }
}
