package coe318.Lab7;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class User_Main implements User_Interface {

    String input;
    Scanner imp = new Scanner(System.in);
    ArrayList<Object> cirelement = new ArrayList<>();

    @Override
    public void start() {
        display();
        run();
    }

    /**
     *
     */
    @Override
    public void display() {
        System.out.println("Enter Input");
    }

    @Override
    public void end() {
        System.out.println("All Done");
    }

    @Override
    public void spice() {
        cirelement.forEach((o) -> {
            System.out.println(o);
        });
    }

    /**
     *
     */
    @Override
    public void run() {
        while (true) {
            input = imp.nextLine();

            if (input.equalsIgnoreCase("end")) {
                end();
                break;
            } else if (input.equalsIgnoreCase("spice")) {
                spice();
            } else {
                String[] value = input.split(" ");
                if (value.length != 4) {
                    System.out.println("Incorrect Parameters.");// display message incorrect parameters
                } else {
                    if (input.toLowerCase().startsWith("v")) {
                        Node n1 = new Node();
                        Node n2 = new Node();
                        n1.id = Integer.parseInt(value[1]);
                        n2.id = Integer.parseInt(value[2]);
                        Voltage v = new Voltage(Double.parseDouble(value[3]), n1, n2);
                        cirelement.add(v);
                    } else if (input.toLowerCase().startsWith("r")) {
                        Node n1 = new Node();
                        Node n2 = new Node();
                        n1.id = Integer.parseInt(value[1]);
                        n2.id = Integer.parseInt(value[2]);
                        Resistor r = new Resistor(Double.parseDouble(value[3]), n1, n2);
                        cirelement.add(r);
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        User_Main m = new User_Main();
        m.start();
    }
}
