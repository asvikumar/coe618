package coe318.Lab7;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Voltage {
    int resistorId;
    double Voltage;
    Node node1, node2;
    static int counter = 1;
    public Voltage (double Voltage, Node node1, Node node2){
        if (Voltage <= 0)
            throw new IllegalArgumentException();
        if (node1 == null || node2 == null)
            throw new IllegalArgumentException();
            
        this.Voltage = Voltage;
        this.node1 = node1;
        this.node2 = node2;
        this.resistorId = counter;
        counter++;   
        }
    public Node[] getNode(){
        return new Node[]{node1, node2};
        }
    @Override
    public String toString(){
        Node[] n = getNode();
        if (n[0].id > n[1].id)
           return ("V" + "" + this.resistorId + " "+ node1+" " + node2 + " DC " + (Voltage));
        else
            return (this.resistorId + "V" + "" + " "+ node2+" " + node1 + " DC " + (-Voltage));
        
        }
    }
