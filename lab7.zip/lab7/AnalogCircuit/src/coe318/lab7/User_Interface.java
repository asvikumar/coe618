package coe318.Lab7;
/**
 *
 * @author Asvigka Kumareswaran
 */
public interface User_Interface {
    
      public void spice();
      public void display();
      public void end();
      public void start();
      public void run();
      
    }
   