package coe318.lab6;
import java.util.ArrayList;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Circuit {
    ArrayList <Resistor> resistor;
    private static Circuit Instance=null;
    
private Circuit(){
    resistor=new ArrayList <>();
}
static Circuit getInstance()
{
    if(Instance==null)
        return Instance= new Circuit();
    else
        return Instance;
}
public void add(Resistor r)
{
resistor.add(r);
}
    @Override
    public String toString()
{
    String out="";
    for (int i=0;i<resistor.size();i++)
        out+= this.resistor.get(i)+"\n";
    return out;
}
}

