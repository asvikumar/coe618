package coe318.lab6;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Node {
    private final int NODE_ID;
    private static int COUNTER=0;
 
public Node(){
        this.NODE_ID=COUNTER;
        COUNTER++;    
}
@Override
public String toString()
{
   return ""+NODE_ID; 
}}