package coe318.lab6;
/**
 *
 * @author Asvigka Kumareswaran
 */
public class Resistor {
    private double Resistance;
    private Node Node1;
    private Node Node2;
    int Resistor_ID;
    private static int Resistor_COUNTER=1;
    
public Resistor(double Resistance, Node Node1, Node Node2)
{if (Resistance<=0)
    throw new IllegalArgumentException("N/a");
if (Node1==null)
     throw new IllegalArgumentException("N/a");
if (Node2==null)
     throw new IllegalArgumentException("N/a");

this.Resistance=Resistance;
this.Node1=Node1;
this.Node2=Node2;
this.Resistor_ID=Resistor_COUNTER;
Resistor_COUNTER++;
    }
public Node[] getNode()
{
    Node[] node={Node1, Node2};
    return node;
}
@Override
public String toString()
{
    return ("R"+Resistor_ID+" "+ Node1+" "+ Node2+" "+ Resistance);
}
}
