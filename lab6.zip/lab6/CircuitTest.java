package coe318.lab6;

/**
 *
 * @author Asvigka Kumareswaran 
 */
public class CircuitTest {
    public static void main(String[]args)
    {
        Node A=new Node();
        Node B= new Node();
        Node C= new Node();
        
        System.out.println(A);
        System.out.println(B);
        System.out.println(C);
        
        Resistor r1= new Resistor(25.0,A,B);
        Resistor r2= new Resistor(30.0,B,C);
        
        Circuit c1= Circuit.getInstance();
        c1.add(r1);
        c1.add(r2);
        System.out.println(c1);
    }
}
