/*
 * @author Asvigka Kumareswaran
 */
package coe318.lab4;
public class Account {
    private String nameofclient;
    private double accountbalance;
    private int accountnumber;
    
public Account (String nameofclient, int accountnumber, double accountbalance)
{
    this.nameofclient= nameofclient;
    this.accountbalance= accountbalance;
    this.accountnumber= accountnumber;
}
public String getNameofclient (){
    return nameofclient;
}
public void setNameofclient (String nameofclient) {
    this.nameofclient = nameofclient;
}
public int getAccountnumber (){
    return accountnumber;
}
public void setAccountnumber (int number)
{
    this.accountnumber = accountnumber;
}
public double getAccountbalance (){
    return accountbalance;
}
public void setAccountbalance (double accountbalance)
{ 
    this.accountbalance = accountbalance;
}
public boolean deposit (double amountnumber) {
    if (amountnumber > 0 )
    {
        this.accountbalance += amountnumber;
        return true;
    } else {
        return false;
    }
    }
public boolean withdraw (double amountnumber) {
    if (amountnumber < this.accountbalance){
    if (amountnumber >0)
    this.accountbalance -= amountnumber;
    return true;
    }else {
     return false;
    }
    }
@Override 
public String toString() {
    return "(" + getNameofclient() + "," + getAccountnumber ()+ "," + String.format ("$%.2f", getAccountbalance ()) + ")";
}
}
