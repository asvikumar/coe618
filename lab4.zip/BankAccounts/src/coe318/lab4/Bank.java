/**
 *
 * @author Asvigka Kumareswaran
 */
package coe318.lab4;

public class Bank {
    private String nameofclient;
    private Account [] accounts;
    private int numAccounts;//number of active accounts

    public Bank(String nameofclient, int maxNumberAccounts) {
        this.nameofclient = nameofclient;
        accounts = new Account[maxNumberAccounts];
        numAccounts = 0;
    }
    public String getNameofclient() {
        return nameofclient;
    }
    public int getNumAccounts() {
        return numAccounts;
    }


    public Account[] getAccounts() {
        return accounts; //Fix this
    }

    public boolean hasAccountNumber(int accountNumber) {
        for (Account account : this.accounts)
        {
            if (account !=null)
            {
                {
                    if (accountNumber == account.getAccountnumber())
                    { return true;
                    }
                }
            }
        } return false;
    }
    public boolean add(Account account) {
        if (hasAccountNumber (account.getAccountnumber()))
        {
            return false;
        }
        else
        { 
        for (int i=0; i <accounts.length ; i++)
        {
        if (accounts [i] == null)
        {
            accounts [i] = account;
            numAccounts ++;
            break;
        }
        }
        }
            return true;
    }

    @Override
    public String toString() {
        String s = getNameofclient() + ": " + getNumAccounts() +
                " of " + getAccounts().length +
                " accounts open";
        for(Account account : getAccounts()) {
            if (account == null) break;
            s += "\n  " + account;
        }
        return s;
    }
}